﻿namespace Maude.Runtime.Views.Telemetry
{
    public enum ChartHoverEvent
	{
		Started,

		Changed,

		Ended,
	}
}

