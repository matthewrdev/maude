﻿using System;
using System.Collections.Generic;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Xaml;


namespace Maude.Runtime.Views.Telemetry
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TelemetryLegendView : ContentView
    {
        public TelemetryLegendView()
        {
            InitializeComponent();
        }
    }
}

