﻿using System;
namespace Maude.Runtime.Telemetry
{
    public static class TelemetryKinds
    {
        public const string Memory = "Memory";

        public const string CPU = "CPU";

        public const string Graphics = "Graphics";
    }
}

